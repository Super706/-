#ifndef _PBDATA_H
#define _PBDATA_H	 


#include <string.h>
#include "stm32f10x.h" //STM32ͷ�ļ�
#include <stdint.h>
#include <stdarg.h>
#include <stdlib.h>
#include "core_cm3.h"
#include "stdio.h"
#include "sys.h"
#include "delay.h"
#include "led.h"
#include "usart.h"
#include "rtc.h"
#include "oled.h"
#include "dht11.h"
//�����豸
#include "esp8266.h"

//Э���ļ�
#include "onenet.h"
#include "mqttkit.h"
//#include <math.h>
//#include <float.h>
//#include <limits.h>
//#include <ctype.h>


//#define FLASH_START_ADDR 0X0801F000   // 0000 1000 0000 0001 1111 0000 0000 0000
	

//extern u8 Dat1,Dat2,Dat3,Dat4;
extern u8 i;

		 				    
#endif
