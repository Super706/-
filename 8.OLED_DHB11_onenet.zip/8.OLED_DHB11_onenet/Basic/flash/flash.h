#ifndef _FLASH_H
#define _FLASH_H 			   
#include "pbdata.h"
 
void FLASH_W(u32 add,u16 dat);
u16 FLASH_R(u32 add);

#endif
