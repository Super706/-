#include "buzzer.h"

uc16 musicl[64] ={ //// �������MIDIwenjian --> https://blog.csdn.net/luozhizhong6666/article/details/104477844
523,600,
523,600,
784,600,
784,600,
880,600,
880,600,
784,600,
0,1200,
698,600,
698,600,
659,600,
659,600,
587,600,
587,600,
523,600,
0,1200,
784,600,
784,600,
698,600,
698,600,
659,600,
659,600,
587,600,
0,1200,
784,600,
784,600,
698,600,
698,600,
659,600,
659,600,
587,600,
0,1200,};

void BUZZER_Init(void)
{
		GPIO_InitTypeDef  GPIO_InitStructure; 	
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOC,ENABLE);       
    GPIO_InitStructure.GPIO_Pin = BUZZER; //ѡ��˿ںţ�0~15��all��                        
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; //ѡ��IO�ӿڹ�����ʽ       
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; //����IO�ӿ��ٶȣ�2/10/50MHz��    
		GPIO_Init(LEDPORT, &GPIO_InitStructure);	
		GPIO_WriteBit(BUZZERPORT,BUZZER,(BitAction)(1));//�رշ�����
}

void BUZZER_BEEP1(void)
{
	u16 i;
	for(i=0; i<200; i++)
	{
		GPIO_WriteBit(BUZZERPORT,BUZZER,(BitAction)(0));//�رշ�����
		delay_us(500);
		GPIO_WriteBit(BUZZERPORT,BUZZER,(BitAction)(1));//�رշ�����
		delay_us(500);
	}
}

void MIDI_PLAY(void)
{
	u16 i,e;
	for(i=0;i<32;i++)
	{
		for(e=0;e<musicl[i*2]*musicl[i*2+1]/1000;e++)
		{
		GPIO_WriteBit(BUZZERPORT,BUZZER,(BitAction)(0));//�رշ�����
		delay_us(500000/musicl[i*2]);
		GPIO_WriteBit(BUZZERPORT,BUZZER,(BitAction)(1));//�رշ�����
		delay_us(500000/musicl[i*2]);
		}
	}
}

