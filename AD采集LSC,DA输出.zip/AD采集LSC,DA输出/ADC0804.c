#include "pbdata.h"	

sbit ADC0804_CS = P0^7;
sbit ADC0804_WR = P3^6;
sbit ADC0804_RD = P3^7;
sbit Duan = P2^6;
sbit Wei = P2^7;


u32 dat = 0;


void ADC0804_Init(void)
{
	P0 = 0X00;
	Duan = 1;
	Duan = 0;
	
	ADC0804_CS = 1;
	ADC0804_WR =1;
	ADC0804_RD = 1;

}

void ADC0804_DValue1(void)//һ��ת��
{	

	ADC0804_CS = 0;
	
	ADC0804_WR = 0;
	ADC0804_WR = 1;
	ADC0804_CS = 1;
	
	delay_ms(200);
	
	ADC0804_CS = 0;
	ADC0804_RD = 0;
	
	P1 = 0xff;
	dat = P1;
	ADC0804_RD = 1;
	ADC0804_CS = 1;

}
void ADC0804_DValue2(void)//һ��ת��
{	
	ADC0804_CS = 0;
	
	ADC0804_WR = 0;
	ADC0804_WR = 1;

	delay_ms(200);

	ADC0804_RD = 0;
	
	P1 = 0xff;
	dat = P1;
	ADC0804_RD = 1;
}

void ADC0804_DValue3(u32 dat)//LCd��ʾ
{	
	
	dat = dat*5000/255; 
	LCD1602_DispNum1(8, 1, dat);	
}
