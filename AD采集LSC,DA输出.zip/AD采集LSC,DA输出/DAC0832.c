#include "pbdata.h"	//������ͷ�ļ� 0001 1111

sbit DAC0832_CS = P3^2;
sbit DAC0832_WR1 = P3^6;

void DAC0832_Init(void)
{
	 DAC0832_CS = 1;
     DAC0832_WR1 = 1;
}

void DAC0832_Demo()
{
		 DAC0832_CS = 0;
		
		 P0 = P1;
	     delay(1);
	     DAC0832_WR1 = 0;
		 DAC0832_WR1 = 1;
		 DAC0832_CS = 1;
}

