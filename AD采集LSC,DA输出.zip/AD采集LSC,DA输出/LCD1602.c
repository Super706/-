#include "pbdata.h" //��������ͷ�ļ�
	sbit LCD1602_EN = P3^4;
	sbit LCD1602_RS = P3^5;
	
void LCD1602_WriteCMD(u8 cmd)//�͵�ַ
	{
		LCD1602_EN = 0;
		LCD1602_RS = 0;
		P0 = cmd;
		LCD1602_EN = 1;
		delay(2);
		LCD1602_EN = 0;
	}
	
void LCD1602_WriteDAT(u8 dat)//д����
	{
		LCD1602_EN = 0;
		LCD1602_RS = 1;
		P0 = dat;
		LCD1602_EN = 1;
		delay(2);
		LCD1602_EN = 0;	
	}

void LCD1602_Init(void)
{
		LCD1602_WriteCMD(0x38);//��ʾģʽ
		LCD1602_WriteCMD(0x0f);//�������
		LCD1602_WriteCMD(0x06);//�����λ
		LCD1602_WriteCMD(0x01);//LCD��Ļ���
}

void LCD1602_DispNum(u8 x, bit y, u8 num)//��ʾ��������
{
	if(y) LCD1602_WriteCMD(0xc0 + x);
	else  LCD1602_WriteCMD(0x80 + x);
	LCD1602_WriteDAT(num+'0');
}

void LCD1602_DispNum1(u8 x, bit y, u16 num)//��ʾ��λ����
{
	
	if(y) LCD1602_WriteCMD(0xc0 + x);
	else  LCD1602_WriteCMD(0x80 + x);
	LCD1602_WriteDAT(num/1000+'0');
	num = num%1000;
	LCD1602_DispNum2(9,1,'.');
	LCD1602_WriteDAT(num/100+'0');
	num = num%100;
	LCD1602_WriteDAT(num/10+'0');
	LCD1602_WriteDAT(num%10+'0');
	
	
}


void LCD1602_DispNum11(u8 x, bit y, u16 num)//��ʾ��λ����
{
	if(y) LCD1602_WriteCMD(0xc0 + x);
	else  LCD1602_WriteCMD(0x80 + x);

	LCD1602_WriteDAT(num/100+'0');
	num = num%100;
	LCD1602_WriteDAT(num/10+'0');
	LCD1602_WriteDAT(num%10+'0');
	

	
	
}
void LCD1602_DispNum2(u8 x, bit y, u8 ch)//��ʾ�����ַ�
{
	if(y) LCD1602_WriteCMD(0xc0 + x);
	else  LCD1602_WriteCMD(0x80 + x);
	LCD1602_WriteDAT(ch);
}

void LCD1602_DispNum3(u8 x, bit y, u8 *p)//��ʾ�����ַ�
{
	if(y) LCD1602_WriteCMD(0xc0 + x);
	else  LCD1602_WriteCMD(0x80 + x);
	while((*p != '\0'))
	LCD1602_WriteDAT(*p ++);
	
	
}