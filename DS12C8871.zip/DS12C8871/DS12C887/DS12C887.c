#include"pbdata.h"

sbit DS12C887_CS = P1^4;
sbit DS12C887_AS = P1^5;
sbit DS12C887_RW = P1^6;
sbit DS12C887_DS = P1^7;

void DS12C887_Init(void)
{
	DS12C887_CS = 1;
	DS12C887_AS = 0;
	DS12C887_DS = 0;
	DS12C887_RW = 0;

}

void DS12C887_WriteDAT(u8 REG,u8 dat)
{
	DS12C887_CS = 0;
	
	DS12C887_DS = 1;
	DS12C887_RW = 1;
	DS12C887_AS = 1;
	P0 = REG;
	DS12C887_AS = 0;
	
	DS12C887_RW = 0;
	P0 = dat;
	DS12C887_RW = 1;
	DS12C887_AS = 1;
	DS12C887_CS = 1;
	
}	

u8 DS12C887_ReadDAT(u8 REG)
{
	u8 dat = 0 ;
	DS12C887_CS = 0;
	
	DS12C887_DS = 1;
	DS12C887_RW = 1;
	DS12C887_AS = 1;
	P0 = REG;
	DS12C887_AS = 0;
	
	DS12C887_DS = 0;
	P0 = 0xff;
	dat = P0 ;
	DS12C887_DS = 1;
	DS12C887_AS = 1;
	
	DS12C887_CS = 1;
	return dat;
}

void DS12C887_InitDate(u8 year,u8 month ,u8 day,\
	u8 week,u8 hour,u8 minute,u8 second)
{
	DS12C887_WriteDAT(9,year);
	DS12C887_WriteDAT(8,month);
	DS12C887_WriteDAT(7,day);
	DS12C887_WriteDAT(6,week);
	DS12C887_WriteDAT(4,hour);
	DS12C887_WriteDAT(2,minute);
	DS12C887_WriteDAT(0,second);	
	
}

void  DS12C887_AlarmSet(u8 Ahour,u8 Aminute,u8 Asecond)
{
	DS12C887_ReadDAT(0x0c);
	DS12C887_WriteDAT(0x0B,0X26);

	DS12C887_WriteDAT(1,Asecond);	
	DS12C887_WriteDAT(3,Aminute);
	DS12C887_WriteDAT(3,Ahour);	
}

















