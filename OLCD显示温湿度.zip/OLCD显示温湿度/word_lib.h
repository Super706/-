#ifndef _WORD_LIB_H
#define _WORD_LIB_H

const unsigned char code F6x8[][6];
const unsigned char code F8X16[];
unsigned char code Hzk[][32];

#endif
