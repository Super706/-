#include "pbdata.h" //��������ͷ�ļ�


void USART_Init(u16 bye)
{
	TMOD &= 0X0F;
	TMOD |= 0X20;
	TH1 = 256 - 11059200/12/32/bye;
	TL1 = TH1;
	TR1 = 1;
	
	SM0 = 0;
	SM1 = 1;
	REN = 1;  
	
	EA = 1;
	ES = 1;
}	

void USART_Int(void) interrupt 4
{
		if(RI)
		{
			RI = 0;
			SBUF = SBUF-0xf0;
			SBUF = SBUF;		
		}
		
		if(TI)
		{
			TI = 0;
		}
}