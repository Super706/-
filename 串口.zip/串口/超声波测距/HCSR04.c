#include "pbdata.h" //��������ͷ�ļ�

sbit TRIG = P1^7;
sbit ECHO = P1^6;
bit HS_SR04_Flag = 0;

void HS_SR04_Init(void)
{
	TRIG = 0;
	ECHO = 0;
	T0_Init();
}

flo HS_SR04_maichong(void)
{

	TRIG = 0;
	TRIG = 1;
	delay1();
	TRIG = 0;
	while(!ECHO);
	TR0 = 1;
	while(ECHO);
	TR0 = 0;
	if(HS_SR04_Flag)
	{
		HS_SR04_Flag = 0;
		return 0;
	}
	return (((TH0*256 +TL0)*108.5/100)*1.7/100);
}

