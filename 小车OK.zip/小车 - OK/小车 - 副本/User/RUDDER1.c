#include "pbdata.h"

void	YW(void)		//ԭλ�޻���״̬
{
    dat1=8;
    dat2=14;
    dat3=10;
    dat4=11;
    dat5=14;
    dat6=13;
}
void	YW2(void)		//ԭλ�л���״̬
{
    dat1=4;
    dat2=14;
    dat3=12;
    dat4=11;
    dat5=14;
    delay(200);
		delay100ms();
    dat6=13;  
}
void	YZ_JCTX(void)//��ת���ͼ��λ��	OK
{
    dat2=14;
    dat3=10;
    dat4=11;
    dat6=5;
    delay100ms();
    dat5=16;
    dat1=8;
    delay500ms();
}
void	ZZ_JCTX(void)//��ת���ͼ��λ��	OK
{

    dat2=14;
    dat3=12;
    dat4=11;
    dat6=22;
    delay100ms();
    dat5=16;
    dat1=8;
    delay(100);
}
//void	YBXJHW(void)//��ת��⵽ͼ��λ���¼�	OK
//{
//    dat2=14;
//    dat3=12;
//    dat4=11;
//    dat6=5;
//    delay500ms();
//    dat5=18;
//    delay100ms();
//    dat1=4;
//    delay500ms();
//}
void	ZBXJHW(void)//��ת��⵽ͼ��λ���¼�	OK
{
    dat2=14;
    dat3=12;
    dat4=11;
    dat6=22;
    delay(100);
    dat5=18;
    delay(100);
    dat1=4;
    delay(100);
}
//void	YBJYHWHL(void)//�ұ߼��л����λ	OK
//{
//    dat1=4;
//    dat5=14;
//    delay(100);
//    dat2=14;
//    delay100ms();
//    dat3=10;
//    dat4=11;
//    delay100ms();
//    dat6=5;
//    delay100ms();
//}
void	ZBJYHWHL(void)//��߼��л����λ	OK
{
    dat1=4;
    dat5=14;
    delay(100);
    dat2=14;
    delay(100);
    dat3=10;
    dat4=11;
    delay(100);
    dat6=22;
    delay(100);
}
void	YBJFHW(void)//�ұ߷Ż���		OK
{
    dat1=8;
    dat2=14;
    dat3=12;
    dat4=11;
    dat5=19;
    dat6=5;
}


//void	ZBJFHW(void)//��߷Ż���		OK
//{
//    dat1=8;
//    dat2=14;
//    dat3=12;
//    dat4=11;
//    dat5=18;
//    dat6=22;
//}

