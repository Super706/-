#include "pbdata.h"

u8 speed = 0;

code u8 STEPMotor_4[] = {0x01,0x02,0x04,0x08};   //4��4�������
code u8 STEPMotor_8[] = {0x01,0x03,0x02,0x06,0x04,0x0c,0x08,0x09};  //4��8�������


void STEPMotor_Init(void)
{
	P1 &= 0xf0;   //ֹͣ
	speed = 5;   //��ֵ
}
void STEPMotor_FRun4(u16 spd,u32 cp)	//������ת
{
	speed = 4;
	while(cp --)
	{
		P1 &= 0xf0;
		
		P1 |= STEPMotor_4[3-cp%4];
		  
		delay_ms(spd);
	}
}
void STEPMotor_RRun4(u16 spd,u32 cp)	//���ķ�ת
{	
	speed = 4;
	while(cp --)
	{
		P1 &= 0xf0;
		P1 |= STEPMotor_4[cp%4];
		delay_ms(spd);
	}
}
void STEPMotor_FRun8(u16 spd,u32 cp)	//������ת
{
	speed = 8;
	while(cp --)
	{
		P1 &= 0xf0; 
		P1 |= STEPMotor_8[7-cp%8];
		delay_ms(spd);
	}
}
void STEPMotor_RRun8(u16 spd,u32 cp)  //���ķ�ת
{
	speed = 8;
	while(cp --)
	{
		P1 &= 0xf0; 
		P1 |= STEPMotor_8[cp%8];
		delay_ms(spd);
	}
}
void STEPMotor_Stop(void)  //ֹͣ
{
	P1 &= 0xf0;   
	speed = 0;   
}
void STEPMotor_ADD(void)  //��
{
	if(speed>1);   
	speed  -- ;   
}
void STEPMotor_DEC(void)   //��
{
	if(speed<100);   
	speed  ++ ;   
}



