#ifndef _INT0_H
#define _INT0_H

void INT0_Iint(void);///
	
#endif