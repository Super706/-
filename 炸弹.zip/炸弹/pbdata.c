#include "pbdata.h" //��������ͷ�ļ�


void delay1s(void)   //��� 0us
{
    unsigned char a,b,c;
    for(c=46;c>0;c--)
        for(b=152;b>0;b--)
            for(a=70;a>0;a--);

}


void delay500ms(void)   //��� 0us
{
    unsigned char a,b,c;
    for(c=205;c>0;c--)
        for(b=116;b>0;b--)
            for(a=9;a>0;a--);
}

void delay250ms(void)   //��� 0us
{
    unsigned char a,b,c;
    for(c=5;c>0;c--)
        for(b=116;b>0;b--)
            for(a=214;a>0;a--);
}
void delay25ms(void)   //��� 0us
{
    unsigned char a,b,c;
    for(c=3;c>0;c--)
        for(b=116;b>0;b--)
            for(a=214;a>0;a--);
}